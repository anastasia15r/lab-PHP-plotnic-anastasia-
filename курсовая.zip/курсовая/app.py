import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

# 1. Инициализация приложения
app = Flask(__name__)
app.secret_key = 'super_secret_key_fixed_final'

# 2. Настройка базы данных
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'database.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# --- МОДЕЛИ ДАННЫХ (Models) ---

class User(db.Model):
    """
    Модель пользователя.
    Параметры: username (логин), password_hash (безопасный пароль), is_admin (роль).
    """
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)

class Note(db.Model):
    """
    Модель заметки (Ресурс с 5+ полями).
    Содержит: заголовок, контент, категорию, приоритет и статус публичности.
    """
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), default='Общее')
    priority = db.Column(db.String(20), default='Средний')
    is_public = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

# --- ОСНОВНЫЕ ФУНКЦИИ ---

@app.route('/')
def index():
    """Отображение публичного контента для всех пользователей."""
    notes = Note.query.filter_by(is_public=True).all()
    return render_template('index.html', notes=notes)

@app.route('/search')
def search():
    """Поиск публичных заметок по заголовку."""
    q = request.args.get('q', '').strip()
    results = Note.query.filter(Note.title.contains(q), Note.is_public == True).all() if q else []
    return render_template('search.html', results=results, query=q)

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Регистрация нового пользователя с хешированием пароля."""
    if request.method == 'POST':
        user = request.form.get('username')
        password = request.form.get('password')
        if User.query.filter_by(username=user).first():
            flash('Имя занято!', 'warning')
        else:
            new_u = User(username=user, password_hash=generate_password_hash(password))
            db.session.add(new_u)
            db.session.commit()
            flash('Регистрация успешна!', 'success')
            return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Вход в систему и создание сессии."""
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form.get('username')).first()
        if user and check_password_hash(user.password_hash, request.form.get('password')):
            session.update({'user_id': user.id, 'is_admin': user.is_admin, 'username': user.username})
            return redirect(url_for('dashboard'))
        flash('Ошибка входа', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Завершение сессии пользователя."""
    session.clear()
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    """Личный кабинет авторизованного пользователя."""
    if 'user_id' not in session: return redirect(url_for('login'))
    notes = Note.query.filter_by(user_id=session['user_id']).all()
    return render_template('dashboard.html', notes=notes)

@app.route('/create', methods=['GET', 'POST'])
def create():
    """Создание ресурса (5 полей) с валидацией."""
    if 'user_id' not in session: return redirect(url_for('login'))
    if request.method == 'POST':
        note = Note(
            title=request.form.get('title'),
            content=request.form.get('content'),
            category=request.form.get('category'),
            priority=request.form.get('priority'),
            is_public='is_public' in request.form,
            user_id=session['user_id']
        )
        db.session.add(note)
        db.session.commit()
        flash('Заметка создана!', 'success')
        return redirect(url_for('dashboard'))
    return render_template('create.html')

# --- ФУНКЦИИ АДМИНИСТРАТОРА ---

@app.route('/admin')
def admin_panel():
    """Главная панель администратора."""
    if not session.get('is_admin'): return redirect(url_for('index'))
    return render_template('admin.html', users=User.query.all(), notes=Note.query.all())

@app.route('/admin/delete_note/<int:nid>')
def admin_delete_note(nid):
    """Удаление ЛЮБОЙ заметки администратором."""
    if session.get('is_admin'):
        n = Note.query.get(nid)
        if n: db.session.delete(n); db.session.commit(); flash('Заметка удалена', 'info')
    return redirect(url_for('admin_panel'))

@app.route('/admin/delete_user/<int:uid>')
def admin_delete_user(uid):
    """Удаление пользователя администратором."""
    if session.get('is_admin') and uid != session['user_id']:
        u = User.query.get(uid)
        if u: db.session.delete(u); db.session.commit(); flash('Пользователь удален', 'info')
    return redirect(url_for('admin_panel'))

@app.route('/admin/promote/<int:uid>')
def admin_promote(uid):
    """Назначение пользователя администратором."""
    if session.get('is_admin'):
        u = User.query.get(uid)
        if u: u.is_admin = True; db.session.commit(); flash('Права обновлены', 'success')
    return redirect(url_for('admin_panel'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        if not User.query.filter_by(username='admin').first():
            db.session.add(User(username='admin', password_hash=generate_password_hash('admin123'), is_admin=True))
            db.session.commit()
    app.run(debug=True)